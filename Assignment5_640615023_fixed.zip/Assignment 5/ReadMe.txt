Welcome to Program 4 from 640615023 Mr.Pisit Pisuttipunpong

Prerequisite
1. Node.JS [https://nodejs.org/en]

Installation Step
1. Go into SourceCode folder
2. run "npm install"
3. run "npm start" to run a program

Thank you :)

Best Regard.